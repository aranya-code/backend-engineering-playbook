terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.80.0, < 7.0.0"
    }

    random = {
      source  = "hashicorp/random"
      version = ">= 3.6.0, < 4.0.0"
    }
  }
}

# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = local.common_tags
  }
}

# ---------------------------------------------------------------------------
# Variables
# ---------------------------------------------------------------------------

variable "aws_region" {
  description = "AWS Region in which the image-processing infrastructure is deployed."
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  description = "Short project identifier used in resource naming."
  type        = string
  default     = "s3-image-processing"

  validation {
    condition     = can(regex("^[a-z0-9-]{3,30}$", var.project_name))
    error_message = "project_name must contain 3-30 lowercase letters, numbers, or hyphens."
  }
}

variable "environment" {
  description = "Deployment environment."
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "staging", "production"], var.environment)
    error_message = "environment must be dev, staging, or production."
  }
}

variable "lambda_package_path" {
  description = <<-EOT
    Path to the prebuilt Lambda deployment ZIP, relative to this Terraform
    configuration's working directory.

    The archive must contain handler.py, image_transformer.py, and the
    dependencies from src/requirements.txt at its root.
    Build Pillow for the Lambda Python runtime and target architecture.
  EOT
  type        = string
  default     = "../build/image-processing.zip"
}

variable "lambda_runtime" {
  description = "Python runtime used by the Lambda function."
  type        = string
  default     = "python3.12"

  validation {
    condition     = contains(["python3.11", "python3.12", "python3.13"], var.lambda_runtime)
    error_message = "Use a supported Python runtime listed in the validation condition."
  }
}

variable "lambda_architecture" {
  description = "Lambda instruction-set architecture."
  type        = string
  default     = "x86_64"

  validation {
    condition     = contains(["x86_64", "arm64"], var.lambda_architecture)
    error_message = "lambda_architecture must be x86_64 or arm64."
  }
}

variable "lambda_timeout" {
  description = "Maximum Lambda execution duration in seconds."
  type        = number
  default     = 30

  validation {
    condition     = var.lambda_timeout >= 1 && var.lambda_timeout <= 900
    error_message = "lambda_timeout must be between 1 and 900 seconds."
  }
}

variable "lambda_memory_size" {
  description = "Lambda memory allocation in MB."
  type        = number
  default     = 1024

  validation {
    condition     = var.lambda_memory_size >= 128 && var.lambda_memory_size <= 10240
    error_message = "lambda_memory_size must be between 128 and 10240 MB."
  }
}

variable "log_retention_days" {
  description = "CloudWatch Logs retention period."
  type        = number
  default     = 30

  validation {
    condition = contains(
      [1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653],
      var.log_retention_days
    )
    error_message = "log_retention_days must be a supported CloudWatch Logs retention value."
  }
}

variable "input_prefix" {
  description = "S3 prefix monitored for incoming images."
  type        = string
  default     = "uploads/"
}

variable "output_prefix" {
  description = "S3 prefix used for processed images."
  type        = string
  default     = "processed/"
}

variable "max_input_size_mb" {
  description = "Maximum input image size accepted by the Lambda handler."
  type        = number
  default     = 10

  validation {
    condition     = var.max_input_size_mb >= 1 && var.max_input_size_mb <= 100
    error_message = "max_input_size_mb must be between 1 and 100."
  }
}

variable "thumbnail_max_width" {
  description = "Maximum thumbnail width in pixels."
  type        = number
  default     = 512

  validation {
    condition     = var.thumbnail_max_width >= 1 && var.thumbnail_max_width <= 4096
    error_message = "thumbnail_max_width must be between 1 and 4096."
  }
}

variable "thumbnail_max_height" {
  description = "Maximum thumbnail height in pixels."
  type        = number
  default     = 512

  validation {
    condition     = var.thumbnail_max_height >= 1 && var.thumbnail_max_height <= 4096
    error_message = "thumbnail_max_height must be between 1 and 4096."
  }
}

variable "max_image_pixels" {
  description = "Maximum number of pixels accepted by the image decoder."
  type        = number
  default     = 40000000

  validation {
    condition     = var.max_image_pixels >= 1000000
    error_message = "max_image_pixels must be at least 1,000,000."
  }
}

variable "lambda_max_retry_attempts" {
  description = "Maximum asynchronous Lambda retry attempts before failure destination delivery."
  type        = number
  default     = 2

  validation {
    condition     = var.lambda_max_retry_attempts >= 0 && var.lambda_max_retry_attempts <= 2
    error_message = "lambda_max_retry_attempts must be between 0 and 2."
  }
}

variable "failure_queue_retention_seconds" {
  description = "How long failed Lambda invocation records remain in the failure queue."
  type        = number
  default     = 1209600

  validation {
    condition = (
      var.failure_queue_retention_seconds >= 60 &&
      var.failure_queue_retention_seconds <= 1209600
    )
    error_message = "SQS retention must be between 60 seconds and 14 days."
  }
}

variable "enable_bucket_versioning" {
  description = "Enable versioning on both image buckets."
  type        = bool
  default     = true
}

variable "common_tags" {
  description = "Additional tags applied to project resources."
  type        = map(string)
  default     = {}
}

# ---------------------------------------------------------------------------
# Locals
# ---------------------------------------------------------------------------

locals {
  effective_project_name = "${var.project_name}-${var.environment}"

  input_bucket_name  = "${local.effective_project_name}-input"
  output_bucket_name = "${local.effective_project_name}-output"
  failure_queue_name = "${local.effective_project_name}-lambda-failure"
  lambda_function_name = "${local.effective_project_name}-processor"

  common_tags = merge(
    {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "Terraform"
      Component   = "s3-image-processing"
    },
    var.common_tags
  )
}

# ---------------------------------------------------------------------------
# Unique Resource Suffix
# ---------------------------------------------------------------------------

resource "random_id" "bucket_suffix" {
  byte_length = 4
}

# ---------------------------------------------------------------------------
# S3 Input Bucket
#
# Original images are uploaded under the configured input prefix.
# Only this bucket generates events for the processing Lambda.
# ---------------------------------------------------------------------------

resource "aws_s3_bucket" "input" {
  bucket = "${local.input_bucket_name}-${random_id.bucket_suffix.hex}"

  force_destroy = false

  tags = merge(local.common_tags, {
    Name    = "${local.input_bucket_name}-${random_id.bucket_suffix.hex}"
    Purpose = "image-input"
  })

  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_s3_bucket_public_access_block" "input" {
  bucket = aws_s3_bucket.input.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_ownership_controls" "input" {
  bucket = aws_s3_bucket.input.id

  rule {
    object_ownership = "BucketOwnerEnforced"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "input" {
  bucket = aws_s3_bucket.input.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }

    bucket_key_enabled = false
  }
}

resource "aws_s3_bucket_versioning" "input" {
  bucket = aws_s3_bucket.input.id

  versioning_configuration {
    status = var.enable_bucket_versioning ? "Enabled" : "Suspended"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "input" {
  bucket = aws_s3_bucket.input.id

  rule {
    id     = "abort-incomplete-multipart-uploads"
    status = "Enabled"

    filter {
      prefix = ""
    }

    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }

  depends_on = [
    aws_s3_bucket_versioning.input
  ]
}

data "aws_iam_policy_document" "input_bucket" {
  statement {
    sid    = "DenyInsecureTransport"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions = [
      "s3:*"
    ]

    resources = [
      aws_s3_bucket.input.arn,
      "${aws_s3_bucket.input.arn}/*"
    ]

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }
}

resource "aws_s3_bucket_policy" "input" {
  bucket = aws_s3_bucket.input.id
  policy = data.aws_iam_policy_document.input_bucket.json

  depends_on = [
    aws_s3_bucket_public_access_block.input
  ]
}

# ---------------------------------------------------------------------------
# S3 Output Bucket
#
# Processed images are written to a separate bucket. This prevents the
# Lambda function from recursively processing its own output objects.
# ---------------------------------------------------------------------------

resource "aws_s3_bucket" "output" {
  bucket = "${local.output_bucket_name}-${random_id.bucket_suffix.hex}"

  force_destroy = false

  tags = merge(local.common_tags, {
    Name    = "${local.output_bucket_name}-${random_id.bucket_suffix.hex}"
    Purpose = "image-output"
  })

  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_s3_bucket_public_access_block" "output" {
  bucket = aws_s3_bucket.output.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_ownership_controls" "output" {
  bucket = aws_s3_bucket.output.id

  rule {
    object_ownership = "BucketOwnerEnforced"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "output" {
  bucket = aws_s3_bucket.output.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }

    bucket_key_enabled = false
  }
}

resource "aws_s3_bucket_versioning" "output" {
  bucket = aws_s3_bucket.output.id

  versioning_configuration {
    status = var.enable_bucket_versioning ? "Enabled" : "Suspended"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "output" {
  bucket = aws_s3_bucket.output.id

  rule {
    id     = "abort-incomplete-multipart-uploads"
    status = "Enabled"

    filter {
      prefix = ""
    }

    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }

  depends_on = [
    aws_s3_bucket_versioning.output
  ]
}

data "aws_iam_policy_document" "output_bucket" {
  statement {
    sid    = "DenyInsecureTransport"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions = [
      "s3:*"
    ]

    resources = [
      aws_s3_bucket.output.arn,
      "${aws_s3_bucket.output.arn}/*"
    ]

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }
}

resource "aws_s3_bucket_policy" "output" {
  bucket = aws_s3_bucket.output.id
  policy = data.aws_iam_policy_document.output_bucket.json

  depends_on = [
    aws_s3_bucket_public_access_block.output
  ]
}

# ---------------------------------------------------------------------------
# SQS Failure Destination
#
# Receives invocation records when asynchronous Lambda processing exhausts
# its retry policy or reaches a terminal failure.
#
# S3 invokes Lambda directly. This queue is the asynchronous invocation
# failure destination, not the primary S3 event-processing queue.
# ---------------------------------------------------------------------------

resource "aws_sqs_queue" "lambda_failure" {
  name = local.failure_queue_name

  message_retention_seconds = var.failure_queue_retention_seconds
  visibility_timeout_seconds = 300
  receive_wait_time_seconds = 20

  sqs_managed_sse_enabled = true

  tags = merge(local.common_tags, {
    Name    = local.failure_queue_name
    Purpose = "lambda-failure-destination"
  })
}

data "aws_iam_policy_document" "lambda_failure_queue" {
  statement {
    sid    = "DenyInsecureTransport"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions = [
      "sqs:*"
    ]

    resources = [
      aws_sqs_queue.lambda_failure.arn
    ]

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }
}

resource "aws_sqs_queue_policy" "lambda_failure" {
  queue_url = aws_sqs_queue.lambda_failure.id
  policy    = data.aws_iam_policy_document.lambda_failure_queue.json
}

# ---------------------------------------------------------------------------
# Lambda CloudWatch Log Group
#
# Create the log group explicitly to control retention and avoid relying
# on Lambda's automatic log-group creation behavior.
# ---------------------------------------------------------------------------

resource "aws_cloudwatch_log_group" "lambda" {
  name              = "/aws/lambda/${local.lambda_function_name}"
  retention_in_days = var.log_retention_days

  tags = merge(local.common_tags, {
    Name    = "/aws/lambda/${local.lambda_function_name}"
    Purpose = "lambda-application-logs"
  })
}

# ---------------------------------------------------------------------------
# Lambda Execution Role
# ---------------------------------------------------------------------------

data "aws_iam_policy_document" "lambda_assume_role" {
  statement {
    sid     = "AllowLambdaAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "lambda" {
  name               = "${local.lambda_function_name}-execution-role"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume_role.json

  tags = merge(local.common_tags, {
    Name    = "${local.lambda_function_name}-execution-role"
    Purpose = "lambda-execution"
  })
}

# ---------------------------------------------------------------------------
# Lambda Execution Permissions
#
# Permissions are restricted to:
# - Writing application logs to the dedicated log group.
# - Reading objects from the configured input bucket and prefix.
# - Writing processed objects to the output bucket.
# - Sending failed asynchronous invocation records to the failure queue.
# ---------------------------------------------------------------------------

data "aws_iam_policy_document" "lambda_execution" {
  statement {
    sid    = "WriteLambdaLogs"
    effect = "Allow"

    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]

    resources = [
      "${aws_cloudwatch_log_group.lambda.arn}:*"
    ]
  }

  statement {
    sid    = "ReadInputImages"
    effect = "Allow"

    actions = [
      "s3:GetObject",
      "s3:GetObjectVersion"
    ]

    resources = [
      "${aws_s3_bucket.input.arn}/${var.input_prefix}*"
    ]
  }

  statement {
    sid    = "WriteProcessedImages"
    effect = "Allow"

    actions = [
      "s3:PutObject"
    ]

    resources = [
      "${aws_s3_bucket.output.arn}/${var.output_prefix}*"
    ]
  }

  statement {
    sid    = "SendFailedInvocationRecords"
    effect = "Allow"

    actions = [
      "sqs:SendMessage"
    ]

    resources = [
      aws_sqs_queue.lambda_failure.arn
    ]
  }
}

resource "aws_iam_role_policy" "lambda_execution" {
  name   = "${local.lambda_function_name}-execution-policy"
  role   = aws_iam_role.lambda.id
  policy = data.aws_iam_policy_document.lambda_execution.json
}

# ---------------------------------------------------------------------------
# Lambda Function
#
# The deployment archive is built outside Terraform and supplied through
# lambda_package_path. It must contain the handler, image transformer, and
# compatible third-party dependencies at the archive root.
# ---------------------------------------------------------------------------

resource "aws_lambda_function" "image_processor" {
  function_name = local.lambda_function_name
  description   = "Processes uploaded images and stores generated thumbnails."

  role          = aws_iam_role.lambda.arn
  runtime       = var.lambda_runtime
  handler       = "handler.lambda_handler"
  architectures = [var.lambda_architecture]

  filename         = var.lambda_package_path
  source_code_hash = filebase64sha256(var.lambda_package_path)

  timeout                        = var.lambda_timeout
  memory_size                    = var.lambda_memory_size
  reserved_concurrent_executions = -1
  publish                         = true

  ephemeral_storage {
    size = 512
  }

  environment {
    variables = {
      INPUT_BUCKET        = aws_s3_bucket.input.bucket
      OUTPUT_BUCKET       = aws_s3_bucket.output.bucket
      INPUT_PREFIX        = var.input_prefix
      OUTPUT_PREFIX       = var.output_prefix
      MAX_INPUT_SIZE_MB   = tostring(var.max_input_size_mb)
      THUMBNAIL_MAX_WIDTH = tostring(var.thumbnail_max_width)
      THUMBNAIL_MAX_HEIGHT = tostring(var.thumbnail_max_height)
      MAX_IMAGE_PIXELS    = tostring(var.max_image_pixels)
      LOG_LEVEL           = "INFO"
    }
  }

  tags = merge(local.common_tags, {
    Name    = local.lambda_function_name
    Purpose = "image-processing"
  })

  depends_on = [
    aws_iam_role_policy.lambda_execution,
    aws_cloudwatch_log_group.lambda
  ]

  lifecycle {
    precondition {
      condition     = fileexists(var.lambda_package_path)
      error_message = "Lambda deployment archive does not exist. Build the ZIP archive and set lambda_package_path before applying Terraform."
    }
  }
}

# ---------------------------------------------------------------------------
# Lambda Asynchronous Invocation Configuration
#
# S3 invokes Lambda asynchronously. Failed invocation records are delivered
# to the SQS destination after the configured retry attempts.
# ---------------------------------------------------------------------------

resource "aws_lambda_function_event_invoke_config" "image_processor" {
  function_name = aws_lambda_function.image_processor.function_name

  maximum_event_age_in_seconds = 3600
  maximum_retry_attempts       = var.lambda_max_retry_attempts

  destination_config {
    on_failure {
      destination = aws_sqs_queue.lambda_failure.arn
    }
  }

  depends_on = [
    aws_sqs_queue_policy.lambda_failure
  ]
}

# ---------------------------------------------------------------------------
# Permission for S3 to Invoke Lambda
#
# Restrict invocation to the input bucket in this AWS account.
# ---------------------------------------------------------------------------

resource "aws_lambda_permission" "allow_s3_invocation" {
  statement_id  = "AllowInvocationFromInputBucket"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.image_processor.function_name
  principal     = "s3.amazonaws.com"

  source_arn     = aws_s3_bucket.input.arn
  source_account = data.aws_caller_identity.current.account_id
}

data "aws_caller_identity" "current" {}

# ---------------------------------------------------------------------------
# S3 Event Notification
#
# Only object-created events under the uploads prefix trigger processing.
# The output bucket is separate and therefore cannot recursively trigger
# this notification configuration.
# ---------------------------------------------------------------------------

resource "aws_s3_bucket_notification" "input" {
  bucket = aws_s3_bucket.input.id

  lambda_function {
    lambda_function_arn = aws_lambda_function.image_processor.arn
    events              = ["s3:ObjectCreated:*"]
    filter_prefix       = var.input_prefix
  }

  depends_on = [
    aws_lambda_permission.allow_s3_invocation
  ]
}

# ---------------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------------

output "input_bucket_name" {
  description = "Name of the S3 bucket receiving original image uploads."
  value       = aws_s3_bucket.input.bucket
}

output "input_bucket_arn" {
  description = "ARN of the input S3 bucket."
  value       = aws_s3_bucket.input.arn
}

output "input_bucket_region" {
  description = "Region containing the input S3 bucket."
  value       = aws_s3_bucket.input.region
}

output "input_upload_prefix" {
  description = "Prefix monitored for incoming image uploads."
  value       = var.input_prefix
}

output "output_bucket_name" {
  description = "Name of the S3 bucket storing processed images."
  value       = aws_s3_bucket.output.bucket
}

output "output_bucket_arn" {
  description = "ARN of the output S3 bucket."
  value       = aws_s3_bucket.output.arn
}

output "output_processed_prefix" {
  description = "Prefix used for generated thumbnails."
  value       = var.output_prefix
}

output "lambda_function_name" {
  description = "Name of the image-processing Lambda function."
  value       = aws_lambda_function.image_processor.function_name
}

output "lambda_function_arn" {
  description = "ARN of the image-processing Lambda function."
  value       = aws_lambda_function.image_processor.arn
}

output "lambda_execution_role_arn" {
  description = "ARN of the Lambda execution role."
  value       = aws_iam_role.lambda.arn
}

output "lambda_log_group_name" {
  description = "CloudWatch Logs group for the image-processing Lambda."
  value       = aws_cloudwatch_log_group.lambda.name
}

output "failure_queue_name" {
  description = "Name of the asynchronous Lambda failure destination queue."
  value       = aws_sqs_queue.lambda_failure.name
}

output "failure_queue_url" {
  description = "URL of the asynchronous Lambda failure destination queue."
  value       = aws_sqs_queue.lambda_failure.url
}

output "failure_queue_arn" {
  description = "ARN of the asynchronous Lambda failure destination queue."
  value       = aws_sqs_queue.lambda_failure.arn
}

output "aws_region" {
  description = "AWS Region used by this deployment."
  value       = var.aws_region
}