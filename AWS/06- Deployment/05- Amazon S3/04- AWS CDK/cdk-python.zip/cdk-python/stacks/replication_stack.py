from aws_cdk import CfnOutput
from aws_cdk import RemovalPolicy
from aws_cdk import Stack
from aws_cdk import aws_iam as iam
from aws_cdk import aws_s3 as s3
from constructs import Construct


class ReplicationStack(Stack):
    """Provision a versioned S3 source bucket with cross-Region replication."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        source_bucket_name: str,
        destination_bucket_arn: str,
        destination_region: str,
        destination_account_id: str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        if not source_bucket_name or not source_bucket_name.strip():
            raise ValueError(
                "source_bucket_name must be a non-empty string."
            )

        if (
            not destination_bucket_arn
            or not destination_bucket_arn.startswith("arn:")
            or not destination_bucket_arn.endswith(":s3:::")
            and ":s3:::" not in destination_bucket_arn
        ):
            raise ValueError(
                "destination_bucket_arn must be a valid S3 bucket ARN."
            )

        if not destination_region or not destination_region.strip():
            raise ValueError(
                "destination_region must be a non-empty string."
            )

        if destination_account_id is not None:
            if (
                not destination_account_id.isdigit()
                or len(destination_account_id) != 12
            ):
                raise ValueError(
                    "destination_account_id must contain 12 digits."
                )

        self.source_bucket = s3.Bucket(
            self,
            "ReplicationSourceBucket",
            bucket_name=source_bucket_name,
            versioned=True,
            encryption=s3.BucketEncryption.S3_MANAGED,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            object_ownership=s3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
            enforce_ssl=True,
            removal_policy=RemovalPolicy.RETAIN,
            auto_delete_objects=False,
        )

        replication_role = iam.Role(
            self,
            "S3ReplicationRole",
            assumed_by=iam.ServicePrincipal("s3.amazonaws.com"),
            description=(
                "Allows Amazon S3 to replicate object versions from "
                "the source bucket to the destination bucket."
            ),
        )

        replication_role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadSourceBucketConfiguration",
                effect=iam.Effect.ALLOW,
                actions=[
                    "s3:GetReplicationConfiguration",
                    "s3:ListBucket",
                ],
                resources=[
                    self.source_bucket.bucket_arn,
                ],
            )
        )

        replication_role.add_to_policy(
            iam.PolicyStatement(
                sid="ReadSourceObjectVersions",
                effect=iam.Effect.ALLOW,
                actions=[
                    "s3:GetObjectVersionForReplication",
                    "s3:GetObjectVersionAcl",
                    "s3:GetObjectVersionTagging",
                ],
                resources=[
                    self.source_bucket.arn_for_objects("*"),
                ],
            )
        )

        replication_role.add_to_policy(
            iam.PolicyStatement(
                sid="ReplicateObjectsToDestination",
                effect=iam.Effect.ALLOW,
                actions=[
                    "s3:ReplicateObject",
                    "s3:ReplicateDelete",
                    "s3:ReplicateTags",
                ],
                resources=[
                    f"{destination_bucket_arn}/*",
                ],
            )
        )

        replication_configuration = {
            "Role": replication_role.role_arn,
            "Rules": [
                {
                    "ID": "ReplicateAllObjects",
                    "Priority": 1,
                    "Status": "Enabled",
                    "Filter": {},
                    "Destination": {
                        "Bucket": destination_bucket_arn,
                        "Account": destination_account_id,
                        "Region": destination_region,
                        "StorageClass": "STANDARD",
                    },
                    "DeleteMarkerReplication": {
                        "Status": "Enabled",
                    },
                }
            ],
        }

        self.source_bucket.add_property_override(
            "ReplicationConfiguration",
            replication_configuration,
        )

        CfnOutput(
            self,
            "SourceBucketName",
            value=self.source_bucket.bucket_name,
            description="Name of the S3 replication source bucket.",
        )

        CfnOutput(
            self,
            "SourceBucketArn",
            value=self.source_bucket.bucket_arn,
            description="ARN of the S3 replication source bucket.",
        )

        CfnOutput(
            self,
            "DestinationBucketArn",
            value=destination_bucket_arn,
            description="ARN of the S3 replication destination bucket.",
        )

        CfnOutput(
            self,
            "ReplicationRoleArn",
            value=replication_role.role_arn,
            description="ARN of the S3 replication IAM role.",
        )